### پروژه چراغ راهنمایی

این پروژه به طراحی یک چراغ راهنمایی ساده می‌پردازد.

این پروژه به کمک سه عدد LED انجام شده است.

نمای کلی مدار بسته شده در فایل به شکل زیر می‌باشد.

![](traffic_light.png)

[منبع](https://projecthub.arduino.cc/krishna_agarwal/traffic-light-using-arduino-a-beginner-project-35f8c6)